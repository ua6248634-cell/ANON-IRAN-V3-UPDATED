#!/bin/bash
# ================================================================
# ANON-IRAN OS v7.0 — ISO Build Script
# Tested on: Debian 12 Bookworm / Ubuntu 22.04+
# Requires: live-build, debootstrap, xorriso, squashfs-tools
# Build time: ~3-5 hours depending on internet speed
# Output: ANON-IRAN-OS-v7.0-amd64.hybrid.iso (~8-12GB)
# ================================================================
set -e
RED='\033[0;31m'; BRED='\033[1;31m'; CYAN='\033[0;36m'
GRN='\033[0;32m'; YLW='\033[1;33m'; NC='\033[0m'

echo -e "${BRED}"
cat << 'BANNER'
 █████╗ ███╗   ██╗ ██████╗ ███╗   ██╗      ██╗ ██████╗ ███████╗
██╔══██╗████╗  ██║██╔═══██╗████╗  ██║     ██╔╝██╔═══██╗██╔════╝
███████║██╔██╗ ██║██║   ██║██╔██╗ ██║    ██╔╝ ██║   ██║███████╗
██╔══██║██║╚██╗██║██║   ██║██║╚██╗██║   ██╔╝  ██║   ██║╚════██║
██║  ██║██║ ╚████║╚██████╔╝██║ ╚████║  ██╔╝   ╚██████╔╝███████║
╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═╝     ╚═════╝ ╚══════╝
BANNER
echo -e "${CYAN}  v7.0 ISO Build System — Ultimate Red Team Platform${NC}"
echo -e "${YLW}  1474+ tools | VoIP | Social Eng | Remote Control | Pentest${NC}"
echo ""

# ── AUTO-NAVIGATE ────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
if [ ! -f "auto/config" ]; then
  if [ -f "$SCRIPT_DIR/auto/config" ]; then
    cd "$SCRIPT_DIR"
  else
    echo -e "${RED}[!] Cannot locate build directory. Run from inside ANON-IRAN-ISO/${NC}"
    exit 1
  fi
fi
BUILD_DIR="$(pwd)"
echo -e "${CYAN}[*] Build directory: $BUILD_DIR${NC}"

# ── ROOT CHECK ───────────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[!] Root required. Re-running with sudo...${NC}"
  exec sudo bash "$0" "$@"
fi

# ── OUTPUT DIRECTORY ─────────────────────────────────────────────
OUTPUT_DIR="$BUILD_DIR/output"
mkdir -p "$OUTPUT_DIR"
echo -e "${CYAN}[*] Output directory: $OUTPUT_DIR${NC}"

# ── INSTALL DEPS ─────────────────────────────────────────────────
echo -e "${CYAN}[*] Installing build dependencies...${NC}"
apt-get update -qq
apt-get install -y --no-install-recommends \
  live-build debootstrap xorriso squashfs-tools \
  grub-pc-bin grub-efi-amd64-bin mtools syslinux isolinux \
  rsync git curl wget ca-certificates gnupg \
  python3 python3-pip

# ── FIX PERMISSIONS ──────────────────────────────────────────────
echo -e "${CYAN}[*] Fixing permissions...${NC}"
chmod +x BUILD.sh START.sh WRITE-USB.sh 2>/dev/null || true
chmod +x auto/config auto/build auto/clean
find config/hooks -name "*.chroot" -exec chmod +x {} \; 2>/dev/null || true
find config/hooks -name "*.live"   -exec chmod +x {} \; 2>/dev/null || true
echo -e "${GRN}[✓] Permissions OK${NC}"

# ── CLEAN ────────────────────────────────────────────────────────
echo -e "${CYAN}[*] Cleaning previous build artifacts...${NC}"
lb clean --purge 2>/dev/null || true
rm -f "$OUTPUT_DIR"/*.iso 2>/dev/null || true

# ── CONFIGURE ────────────────────────────────────────────────────
echo -e "${CYAN}[*] Configuring live-build...${NC}"
./auto/config
echo -e "${GRN}[✓] Configuration OK${NC}"

# ── BUILD ────────────────────────────────────────────────────────
echo -e "${BRED}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BRED}║  STARTING ISO BUILD — DO NOT INTERRUPT                  ║${NC}"
echo -e "${BRED}║  Estimated time: 3-5 hours                              ║${NC}"
echo -e "${BRED}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

START=$(date +%s)
lb build 2>&1 | tee "$OUTPUT_DIR/build.log"
BUILD_EXIT=$?
END=$(date +%s)
ELAPSED=$(( END - START ))

# ── FIND ISO (multiple possible names) ───────────────────────────
ISO_FILE=""
for pattern in \
  "ANON-IRAN-OS-v7.0-amd64.hybrid.iso" \
  "live-image-amd64.hybrid.iso" \
  "live-image.hybrid.iso" \
  "*.hybrid.iso" \
  "*.iso"; do
  found=$(find "$BUILD_DIR" -maxdepth 2 -name "$pattern" 2>/dev/null | head -1)
  if [ -n "$found" ] && [ -f "$found" ] && [ -s "$found" ]; then
    ISO_FILE="$found"
    break
  fi
done

# ── COPY ISO TO OUTPUT ────────────────────────────────────────────
if [ -n "$ISO_FILE" ] && [ -f "$ISO_FILE" ]; then
  DEST="$OUTPUT_DIR/ANON-IRAN-OS-v7.0-amd64.hybrid.iso"
  if [ "$ISO_FILE" != "$DEST" ]; then
    echo -e "${CYAN}[*] Copying ISO to output folder...${NC}"
    cp "$ISO_FILE" "$DEST"
  fi
  ISO_SIZE=$(du -sh "$DEST" | awk '{print $1}')
  ISO_MD5=$(md5sum "$DEST" | awk '{print $1}')

  echo ""
  echo -e "${BRED}╔══════════════════════════════════════════════════════════╗"
  echo -e "║       BUILD COMPLETE — ANON-IRAN OS v7.0                ║"
  echo -e "╚══════════════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  ${GRN}✓ ISO:${NC}    $DEST"
  echo -e "  ${GRN}✓ Size:${NC}   $ISO_SIZE"
  echo -e "  ${GRN}✓ MD5:${NC}    $ISO_MD5"
  echo -e "  ${GRN}✓ Time:${NC}   ${ELAPSED}s ($(( ELAPSED/60 )) min)"
  echo ""
  echo -e "${CYAN}  ══════════════ HOW TO USE ══════════════${NC}"
  echo -e ""
  echo -e "  ${YLW}▶ Open ISO file:${NC}"
  echo -e "    xdg-open $OUTPUT_DIR/"
  echo ""
  echo -e "  ${YLW}▶ Test in VirtualBox/VMware:${NC}"
  echo -e "    File → New VM → Use ISO: $DEST"
  echo ""
  echo -e "  ${YLW}▶ Test in QEMU:${NC}"
  echo -e "    qemu-system-x86_64 -m 4096 -enable-kvm -cdrom $DEST -boot d"
  echo ""
  echo -e "  ${YLW}▶ Write to USB (replace /dev/sdX):${NC}"
  echo -e "    sudo dd if=$DEST of=/dev/sdX bs=4M status=progress oflag=sync"
  echo -e "    sudo bash WRITE-USB.sh $DEST /dev/sdX"
  echo ""
  echo -e "  ${YLW}▶ Output folder:${NC}"
  echo -e "    $OUTPUT_DIR/"
  echo ""
  # Auto-open output folder if GUI available
  if command -v xdg-open >/dev/null 2>&1 && [ -n "$DISPLAY" ]; then
    echo -e "${CYAN}[*] Opening output folder...${NC}"
    xdg-open "$OUTPUT_DIR/" 2>/dev/null &
  elif command -v nautilus >/dev/null 2>&1 && [ -n "$DISPLAY" ]; then
    nautilus "$OUTPUT_DIR/" 2>/dev/null &
  elif command -v thunar >/dev/null 2>&1 && [ -n "$DISPLAY" ]; then
    thunar "$OUTPUT_DIR/" 2>/dev/null &
  fi
  echo -e "${GRN}[✓] ISO is ready in: $OUTPUT_DIR/${NC}"
  exit 0
else
  echo ""
  echo -e "${RED}╔══════════════════════════════════════════════════════════╗"
  echo -e "║  BUILD FAILED — ISO not found                           ║"
  echo -e "╚══════════════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "${RED}[!] lb build exit code: $BUILD_EXIT${NC}"
  echo -e "${CYAN}[*] Check build log: $OUTPUT_DIR/build.log${NC}"
  echo -e "${CYAN}[*] Last 30 lines of log:${NC}"
  tail -30 "$OUTPUT_DIR/build.log" 2>/dev/null || tail -30 build.log 2>/dev/null
  echo ""
  echo -e "${YLW}[*] Common fixes:${NC}"
  echo -e "    1. Run: sudo lb clean --purge && sudo bash BUILD.sh"
  echo -e "    2. Check network: curl -I https://deb.debian.org"
  echo -e "    3. Free space: df -h (need 20GB+)"
  exit 1
fi
