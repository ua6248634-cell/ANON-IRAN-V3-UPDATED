#!/bin/bash
# ANON-IRAN OS v7.0 — Master Launcher
# Usage: sh START.sh   OR   bash START.sh   OR   ./START.sh

# Auto-navigate to script directory
SCRIPT_PATH="${BASH_SOURCE[0]:-$0}"
SCRIPT_DIR="$(cd "$(dirname "$SCRIPT_PATH")" 2>/dev/null && pwd)"
cd "$SCRIPT_DIR" || { echo "[!] Cannot navigate to build dir"; exit 1; }
echo "[*] Build dir: $(pwd)"

# Escalate to root
if [ "$(id -u)" -ne 0 ]; then
  echo "[*] Elevating to root..."
  exec sudo bash "$0" "$@"
fi

# Fix permissions
chmod +x BUILD.sh START.sh WRITE-USB.sh 2>/dev/null || true
chmod +x auto/config auto/build auto/clean 2>/dev/null || true
find config/hooks -name "*.chroot" -exec chmod +x {} \; 2>/dev/null || true
find config/hooks -name "*.live"   -exec chmod +x {} \; 2>/dev/null || true
echo "[✓] Permissions fixed"

# Install build deps
apt-get update -qq 2>/dev/null || true
apt-get install -y --no-install-recommends \
  live-build debootstrap xorriso squashfs-tools \
  grub-pc-bin grub-efi-amd64-bin mtools syslinux isolinux \
  rsync git curl wget ca-certificates gnupg python3 python3-pip \
  2>/dev/null || true
echo "[✓] Dependencies installed"

# Run build
echo "[*] Starting ISO build..."
exec bash BUILD.sh "$@"
